/***************************
	 FILE NAME: KXG03.h
****************************/

#ifndef _KXG03_H_
#define _KXG03_H_
#include <Arduino.h>

#define KXG03_DEVICE_ADDRESS_4E   (0x4E)    // 7bit Addrss
#define KXG03_DEVICE_ADDRESS_4F   (0x4F)    // 7bit Address
// #define KXG03_WHO_AM_I_VAL        (0x24)
#define KXG03_WHO_AM_I_VAL        (0xED)    // sample

#define KXG03_GYRO_XOUT_L         (0x02)
#define KXG03_ACC_XOUT_L          (0x08)
#define KXG03_WHO_AM_I            (0x30)
#define KXG03_STATUS1             (0x36)
#define KXG03_ACCEL_ODR_WAKE      (0x3E)
#define KXG03_STDBY               (0x43)

// �N���X�̒�`
class KXG03
{
  public:
         KXG03(void) ;
    byte init(unsigned char dev_addr) ;
    byte get_rawval(unsigned char *data) ;
    byte get_val(float *data) ;
    byte write(unsigned char memory_address, unsigned char *data, unsigned char size) ;
    byte read(unsigned char memory_address, unsigned char *data, int size) ;
  private:
    unsigned char device_address ;
} ;

#endif // _KXG03_H_
